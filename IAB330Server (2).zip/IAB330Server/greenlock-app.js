﻿'use strict';

require('greenlock-express').create({

  version: 'draft-11'
, server: 'https://acme-v02.api.letsencrypt.org/directory'  // staging
, email: 'n9699333@qut.edu.au'                                     // CHANGE THIS
, agreeTos: true
, approveDomains: [ 'streamrqut.be' ]              // CHANGE THIS
, challenges: { 'http-01': require('le-challenge-fs').create({ webrootPath: '/tmp/acme-challenges' }) }
, store: require('le-store-certbot').create({ webrootPath: '/tmp/acme-challenges' })
, app: require('./app.js')

//, app: require('express')().use('/', function (req, res) {
//    res.setHeader('Content-Type', 'text/html; charset=utf-8')
//    res.end('Hello, World!\n\n💚 🔒.js');
//  })

, app: require('./app.js')
//, debug: true
}).listen(80, 443);