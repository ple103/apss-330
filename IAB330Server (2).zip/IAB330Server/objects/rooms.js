// Contains code for operations on the pool of rooms on the server.

var rooms = [];

// Constructor
function Rooms() {
	
}

Rooms.prototype.addRoom = async function addRoom(room) {
	// Proceed only if the object parsed is roughly of a room object.
	if (room.title != undefined) {
		rooms.push(room);
		room.id = rooms.length - 1;
	}
}

Rooms.prototype.getRoom = function getRoom(id) {
	return rooms[id];
}

Rooms.prototype.getRooms = async function getRooms() {
	var roomsPrepared = [];
	for (var i = 0; i < rooms.length; i++) {
		var room = await rooms[i].generateObject();
		roomsPrepared.push(room);
		console.log(roomsPrepared[i]);
	}
	return roomsPrepared;
}

Rooms.prototype.addUserToRoom = async function addUserToRoom(userSocket, roomId) {
	var room = this.getRoom(roomId);
	room.addUser(userSocket);
	console.log("User socket added to room " + roomId);
}

module.exports = Rooms;