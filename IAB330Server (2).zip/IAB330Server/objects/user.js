// Contains code for individual rooms.
const uuidv4 = require('uuid/v4');

var token = uuidv4();

// Constructor
function User() {
	// Initialize all instance properties
	this.username;
	this.id;
}

User.prototype.getToken = async function getToken() {
	return token;
}

module.exports = User;

