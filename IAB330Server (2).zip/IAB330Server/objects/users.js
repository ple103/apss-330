// Contains code for individual rooms.
const uuidv4 = require('uuid/v4');
var mysql = require('mysql'); 
var crypto = require('crypto');
var User = require('../objects/user');

var con = mysql.createConnection({
  host: "streamr.ctsj2wr8rptr.ap-southeast-2.rds.amazonaws.com",
  user: "iab330",
  password: "iab330assignment",
  database: "streamr"
});

// Constructor
function Users() {
	this.users = [];
}

Users.prototype.registerUser = async function registerUser(username, password) {
	return new Promise(async function (resolve, reject) {
		var passwordData = saltHashPassword(password);
	  var sql = "INSERT INTO users (username, password, salt) VALUES (?, ?, ?)";
	  con.query(sql,[username, passwordData.passwordHash, passwordData.salt], function (err, result) {
		if (err) {
			console.log(err);
			resolve(false);
		} else {
			console.log("1 record inserted");
			resolve(true);
		}
	  });
	});
}

Users.prototype.logoutUser = async function logoutUser(id, token) {
	return new Promise(async function (resolve, reject) {
		if (this.users[id].token == token) {
			this.users[id] = null;
			resolve(true);
		} else {
			resolve(false);
		}
	});
}

function saltHashPassword(userpassword) {
    var salt = genRandomString(16); /** Gives us salt of length 16 */
    return sha512(userpassword, salt);
    console.log('UserPassword = '+userpassword);
    console.log('Passwordhash = '+passwordData.passwordHash);
    console.log('nSalt = '+passwordData.salt);
}

Users.prototype.loginUser =  function loginUser(username, password) {
	return new Promise(async function (resolve, reject) {
		//var passwordData = saltHashPassword(password);
		await getUserData(username, password).then(function (account) {this.account = account;});
		console.log(this.account);
		console.log('Got user data');
		if (this.account == false) {
			resolve(false);
		}
		else {
			var saltedPassword = sha512(password, this.account.salt);
			console.log("OG " + saltedPassword.passwordHash);
			console.log("DB " + this.account.password);
			if (saltedPassword.passwordHash == this.account.password) {
				var user = new User();
				user.username = this.account.username;
				resolve(user);
			} else {
				resolve(false);
			}
		}
	});	
}

function getUserData(username, password) {
	return new Promise(function (resolve, reject) {
	  var sql = "SELECT * FROM users WHERE username = ?";
	  con.query(sql,[username], function (err, result) {
		if (err) {
			resolve(false);
		} else {
			console.log("1 record found");
			resolve(result[0]);
		}
	  });
	});
}

function saltHashPassword(userpassword) {
    var salt = genRandomString(16); /** Gives us salt of length 16 */
    return sha512(userpassword, salt);
    console.log('UserPassword = '+userpassword);
    console.log('Passwordhash = '+passwordData.passwordHash);
    console.log('nSalt = '+passwordData.salt);
}

/**
 * generates random string of characters i.e salt
 * @function
 * @param {number} length - Length of the random string.
 */
var genRandomString = function(length){
    return crypto.randomBytes(Math.ceil(length/2))
            .toString('hex') /** convert to hexadecimal format */
            .slice(0,length);   /** return required number of characters */
};

/**
 * hash password with sha512.
 * @function
 * @param {string} password - List of required fields.
 * @param {string} salt - Data to be validated.
 */
var sha512 = function(password, salt){
    var hash = crypto.createHmac('sha512', salt); /** Hashing algorithm sha512 */
    hash.update(password);
    var value = hash.digest('hex');
    return {
        salt:salt,
        passwordHash:value
    };
};

module.exports = Users;

