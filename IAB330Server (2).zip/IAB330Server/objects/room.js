// Contains code for individual rooms.
const uuidv4 = require('uuid/v4');

var users = [];
var messages = [];
var token = uuidv4();

// Constructor
function Room() {
	// Initialize all instance properties
	this.title;
	this.owner = "Steven Harse"
	this.id;
	this.media = { mediaId: "" };
}

Room.prototype.generateObject = async function generateObject() {
	return {title: this.title, media: this.media, playbackState: this.playbackState};
}

Room.prototype.addUser = async function addUser(user) {
	users.push(user);
}

Room.prototype.getAllUsers = async function getAllUsers() {
	return users;
}

Room.prototype.getToken = async function getToken() {
	return token;
}

Room.prototype.addMessage = async function addMessage(message) {
	messages.push(message);
}

module.exports = Room;

