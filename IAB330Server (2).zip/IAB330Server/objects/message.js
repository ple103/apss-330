// Constructor
function Message() {
	// Initialize all instance properties
	this.Author;
	this.MessageBody;
	this.SendTime;
}

module.exports = Message;

