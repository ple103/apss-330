var express = require('express');
var fetchVideoInfo = require('youtube-info');
var util = require('util')
var router = express.Router();
var Room = require('../objects/room');
var Rooms = require('../objects/rooms');
var Users = require('../objects/users');
var testRoom = new Room();
var testRoom2 = new Room();
var allRooms = new Rooms();
allRooms.addRoom(testRoom);
allRooms.addRoom(testRoom2);

var users = new Users();

router.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

/* GET YouTube page. */
router.get('/youtubeview', function(req, res, next) {
  res.render('YouTubeView', { title: 'Express' });
});

// User registers an account

router.put("/account", async function(req, res) {
	console.log('request =' + JSON.stringify(req.body));
	if (req.body.username != null && req.body.password != null) {
		await users.registerUser(req.body.username, req.body.password).then(function (accountCreation) {
			this.accountCreation = accountCreation;
		});
		
		if (this.accountCreation) {
			res.end(JSON.stringify({success: true}));
		} else {
			res.end(JSON.stringify({success: false}));
		}
	} else {
		res.end(JSON.stringify({message: "nope.jpg"}));
	}
});

router.post("/account/logout", async function(req, res) {
	console.log('request =' + JSON.stringify(req.body));
	if (req.body.username != null && req.body.password != null) {
		await users.logoutUser(req.body.id, req.body.token).then(function (accountLogout) {
			this.accountLogout = accountLogout;
		});
		
		if (this.accountLogout) {
			res.end(JSON.stringify({success: true}));
		} else {
			res.end(JSON.stringify({success: false}));
		}
	} else {
		res.end(JSON.stringify({message: "nope.jpg"}));
	}
});

router.post("/account", async function(req, res) {
	console.log('request =' + JSON.stringify(req.body));
	if (req.body.username != null && req.body.password != null) {
		await users.loginUser(req.body.username, req.body.password).then(async function (account) {
			this.account = account;
			account.id = users.users.push(account) - 1;
			var token = await this.account.getToken();
			var sendAccount = {username: account.username, id: account.id, token: token}
			res.end(JSON.stringify(sendAccount));
		});
	} else {
		res.end(JSON.stringify({message: "nope.jpg"}));
	}
});

router.get("/room/:id", (req, res) => {
	var id = req.params.id;
    getRoom(id, data => {
		console.log(JSON.stringify(data));
		res.end(JSON.stringify(data));
	});
});

router.put("/room", async function(req, res) {
	console.log('request =' + JSON.stringify(req.body));
	var room = new Room();
	room.title = req.body.Title;
	var videoInfo = await fetchVideoInfo(req.body.CurrentMedia.mediaId)
	room.media.mediaId = req.body.CurrentMedia.mediaId;
	room.media.thumbnailUrl = videoInfo.thumbnailUrl;
	room.media.playbackState = 0;
	await allRooms.addRoom(room);
	
	getRoom(room.id, data => {
		console.log(JSON.stringify(data));
		res.end(JSON.stringify(data));
	});
});

router.get("/rooms", (req, res) => {
    getRooms(data => {
		res.end(JSON.stringify(data));
	});
});

async function getRoom(id, _callback) {
  //has some data
  var roomData = await allRooms.getRoom(id);

  //returns data in callback
  _callback(roomData);
}

async function getRooms(_callback) {
  //has some data
  var roomData = await allRooms.getRooms();

  //returns data in callback
  _callback(roomData);
}

const WebSocket = require('ws');

const wss = new WebSocket.Server({ port: 1337 });

wss.on('connection', function connection(ws, req) {
	console.log(req.connection.remoteAddress);
	ws.on('message', async function incoming(message) {
	    console.log('received: %s', message);
		var response = JSON.parse(message);
		var room = await allRooms.getRoom(response.room);
		var token = await room.getToken();
		if (response.msg == "connect") {
			roomSocketConnect(ws, response, room, token);
			return;
		} 
		if (token != response.token) {
			var unauthorizedData = {message:"unauthorized", roomId: room.id};
			ws.send(JSON.stringify(unauthorizedData));
		} else if (response.msg == "mediaChange") {
			roomSocketMediaChange(ws, response, room);
		} else if (response.msg == "getMedia") {
			roomSocketGetMedia(ws, response, room);
		} else if (response.msg == "playbackStateChange") {
			roomSocketPlaybackStateChange(ws, response, room);
		} else if (response.msg == "message") {
			roomSocketMessage(ws, response, room);
		}
	});
	ws.on('close', function close() {
	    console.log('disconnected');
	});
});

async function roomSocketConnect(ws, response, room, token) {
	room.addUser(ws);
	
	var initialUserData = {message:"allocation", token: token, room: room.id};
	
	//allRooms.addUserToRoom(token, response.room);
	ws.send(JSON.stringify(initialUserData));
}

async function roomSocketGetMedia(ws, response, room) {
	
	var response = {message:"mediaChange", media: room.media};
	
	//allRooms.addUserToRoom(token, response.room);
	ws.send(JSON.stringify(response));
}

async function roomSocketMediaChange(ws, response, room) {
	var users = await room.getAllUsers();
	var videoInfo = await fetchVideoInfo(response.videoId)
	room.media.mediaId = response.videoId;
	room.media.thumbnailUrl = videoInfo.thumbnailUrl;
	var mediaChangeData = {message:"mediaChange", media: room.media};
	console.log("Changing media to " + response.videoId + " for room " + room.id);
	broadcastObjectToRoom(users, mediaChangeData);
}

async function roomSocketPlaybackStateChange(ws, response, room) {
	var users = await room.getAllUsers();
	room.media.playbackState = response.playbackState;
	var mediaChangeData = {message:"mediaChange", media: room.media};
	broadcastObjectToRoom(users, mediaChangeData);
}

async function roomSocketMessage(ws, response, room) {
	var users = await room.getAllUsers();
	room.addMessage(response.messageData);
	var messageData = {message:"message", messageData: response.messageData};
	broadcastObjectToRoom(users, messageData);
}

function broadcastObjectToRoom(users, data) {
	for (var i = 0; i < users.length; i++) {
		try {
			users[i].send(JSON.stringify(data));
			console.log("Contacted user " + i);
		} catch (error) {
			removeWebSocketClient(users, i);
		}
	}
}

function removeWebSocketClient(users, userIndex) {
	console.log("Removing user " + userIndex + " from the room, as their connection has closed.")
	users.splice(userIndex, 1);
}


module.exports = router;
